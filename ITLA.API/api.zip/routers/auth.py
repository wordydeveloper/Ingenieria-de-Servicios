import logging
from fastapi import APIRouter, Body, HTTPException
from pydantic import BaseModel, EmailStr
from shared.utils import execute_query
import datetime

router = APIRouter(prefix="/auth", tags=["auth"])

class UsuarioRegistro(BaseModel):
    codigoUsuario: str
    clave: str

@router.post("/registrar")
def registrar(usuario: UsuarioRegistro = Body()):
    try:
        query = """
        INSERT INTO usuario (codigo_usuario, clave)
        VALUES (%s, %s)
        """
        values = (
            usuario.codigoUsuario,
            usuario.clave
        )

        execute_query(query, values)

        return {"mensaje": "Usuario registrado correctamente"}
    except Exception as e:

        logging.exception("Ocurrió un error inesperado")

        raise HTTPException(status_code=500, detail=str(e))

@router.get("/usuarios")
def obtener_usuarios():
    try:
        query = "SELECT * FROM usuario"
        result = execute_query(query)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
