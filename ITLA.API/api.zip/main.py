from fastapi import FastAPI
from routers import auth
import logging


app = FastAPI()

app.include_router(auth.router)
logging.basicConfig(level=logging.DEBUG)
