import psycopg2
from typing import Optional, Any, List, Dict

from database.connection import get_connection


def snake_to_camel(snake_str: str) -> str:
    parts = snake_str.split('_')
    return parts[0] + ''.join(word.capitalize() for word in parts[1:])


def snake_to_camel_dict(row: dict) -> dict:
    return {snake_to_camel(k): v for k, v in row.items()}


def execute_query(
    query: str,
    values: tuple = (),
    conn: Optional[psycopg2.extensions.connection] = None
) -> Optional[List[Dict[str, Any]]]:
    close_connection = False

    if conn is None:
        conn = get_connection()
        close_connection = True

    cursor = conn.cursor()
    result = None

    try:
        cursor.execute(query, values)

        if cursor.description:  # es un SELECT
            columns = [desc[0] for desc in cursor.description]
            rows = cursor.fetchall()
            result = [
                snake_to_camel_dict(dict(zip(columns, row)))
                for row in rows
            ]
        elif close_connection:
            conn.commit()

    except Exception as e:
        if close_connection:
            conn.rollback()
        raise e
    finally:
        cursor.close()
        if close_connection:
            conn.close()

    return result
